#include <iostream>
#include "Character.h"

using namespace Assesment;

int main()
{
    Character game;
    game.CreateCharacter();
}
