// ExceptionHandling.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <Windows.h>
#include <string>
#include <vector>

#include <cassert>

bool TryParse(const std::string& str, int& value)
{
    try
    {
        value = std::stoi(str);
        return true;
    }
    catch (const std::invalid_argument& e)
    {
        std::cout << "[TryParseFailed]: " << e.what() << "\n";
        return false;
    }

    std::cout << "Unknown Error\n";
    return false;
}
bool TryParse(const std::string& str, float& value)
{
    try
    {
        value = std::stof(str);
        return true;
    }
    catch (const std::invalid_argument& e)
    {
        std::cout << "[TryParseFailed]: " << e.what() << "\n";
        return false;
    }

    std::cout << "Unknown Error\n";
    return false;
}
bool TryParse(const std::string& str, bool& value)
{
    try
    {
        if (str == "true") { value = true; }
        else if (str == "false") { value = false; }
        else 
        { 
            int numVal = std::stoi(str);
            if (numVal == 0)
            {
                value = false;
            }
            else if (numVal == 1)
            {
                value = true;
            }
            else
            {
                std::string errorMsg = "String Value " + str + " is invalid";
                throw std::invalid_argument(errorMsg);
            }
        }
        return true;
    }
    catch (const std::invalid_argument& e)
    {
        std::cout << "[TryParseFailed]: " << e.what() << "\n";
        return false;
    }

    std::cout << "Unknown Error\n";
    return false;
}

void AddInts(std::vector<int*>& crazyInts, const int amount)
{
    crazyInts.push_back(new int[amount]);
}

void AddBadData(std::vector<int*>& crazyInts)
{
    if (rand() % 2 == 0)
    {
        AddInts(crazyInts, 10000000);
    }
    else
    {
        AddInts(crazyInts, 10);
    }
}
void DeleteBadData(std::vector<int*>& crazyInts)
{
    if (rand() % 4 == 0)
    {
        int randIndex = rand() % crazyInts.size();
        auto iter = crazyInts.begin() + randIndex;

        delete[](*iter);
        crazyInts.erase(iter);
    }
}

int main()
{
    std::cout << "Hello World!\n";
    OutputDebugStringA("hello class\n");

    int myValue = 0;
    myValue = 15 * 100 + 1;

    // use if statements to catch invalid values/responses and write/print to output to track
    //      and solve later
    // can be used for personal debugging approaches (print if breakpoints are not easy to use)
    if (myValue < 0)
    {
        OutputDebugStringA(">>>>>>WARNING: value should not be less than 0\n");
    }

    assert(myValue >= 0, "Value should not be less than 0\n");

    try
    {
        myValue = std::stoi("100");
        int divValue = 0;
        if (divValue == 0)
        {
            throw std::runtime_error("Can't divide by 0!");
        }
        myValue = myValue / divValue;
    }
    catch (const std::invalid_argument& e)
    {
        std::cout << "Invalid Argument [" << e.what() << "]\n";
    }
    catch (const std::runtime_error& e)
    {
        std::cout << "Runtime Error [" << e.what() << "]\n";
    }
    
    std::cout << "My Value is " << myValue << "\n";

    //std::vector<int*> crazyInts;
    //while (true)
    //{
    //    system("cls");
    //    AddBadData(crazyInts);
    //    DeleteBadData(crazyInts);
    //    system("pause");
    //}



    //int myResult = 0;
    //bool myBoolResult = false;
    //std::string myString = "HelloWorld";
    //while (myString != "exit")
    //{
    //    system("cls");
    //    std::cout << "Enter Bool (exit to quit): ";
    //    std::cin >> myString;
    //    if (TryParse(myString, myResult))
    //    {
    //        std::cout << "TryParse was a success : " << myResult << "\n";
    //    }
    //    else
    //    {
    //        std::cout << "[Error] TryParse failed\n";
    //    }
    //    system("pause");
    //}
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu

// Tips for Getting Started: 
//   1. Use the Solution Explorer window to add/manage files
//   2. Use the Team Explorer window to connect to source control
//   3. Use the Output window to see build output and other messages
//   4. Use the Error List window to view errors
//   5. Go to Project > Add New Item to create new code files, or Project > Add Existing Item to add existing code files to the project
//   6. In the future, to open this project again, go to File > Open > Project and select the .sln file
